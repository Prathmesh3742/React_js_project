export const data3 = [
    {
      id: 1,
      question: "Who was the first emperor of the Maurya dynasty?",
      answers: [
        {
          text: "Ashoka the Great",
          correct: false,
        },
        {
          text: "Akbar the Great",
          correct: false,
        },
        {
          text: "Harsha",
          correct: false,
        },
        {
          text: "Chandragupta Maurya",
          correct: true,
        },
      ],
    },
    {
        id: 2,
        question: "Which event marked the end of Mughal rule in India?",
        answers: [
          {
            text: "Revolt of 1857",
            correct: true,
          },
          {
            text: "Battle of Plassey",
            correct: false,
          },
          {
            text: "Battle of Panipat",
            correct: false,
          },
          {
            text: "Sepoy Mutiny",
            correct: false,
          },
        ],
      },
      {
        id: 3,
        question: "Who was the founder of the Gupta Empire?",
        answers: [
          {
            text: "Chandragupta I",
            correct: true,
          },
          {
            text: "Ashoka the Great",
            correct: false,
          },
          {
            text: "Harsha",
            correct: false,
          },
          {
            text: "Babur",
            correct: false,
          },
        ],
      },
      {
        id: 4,
        question: "The Indus Valley Civilization was primarily centered around which river?",
        answers: [
          {
            text: "Ganges River",
            correct: false,
          },
          {
            text: "Yamuna River",
            correct: false,
          },
          {
            text: "Indus River",
            correct: true,
          },
          {
            text: "Brahmaputra River",
            correct: false,
          },
        ],
      },
      {
        id: 5,
        question: "The famous Maurya ruler Ashoka converted to which religion after the Kalinga War?",
        answers: [
          {
            text: "Hinduism",
            correct: false,
          },
          {
            text: "Buddhism",
            correct: true,
          },
          {
            text: "Jainism",
            correct: false,
          },
          {
            text: "Sikhism",
            correct: false,
          },
        ],
      },
      {
        id: 6,
        question: "The Taj Mahal was built by Emperor Shah Jahan as a tomb for his wife. What was her name?",
        answers: [
          {
            text: "Anarkali",
            correct: false,
          },
          {
            text: "Jahanara Begum",
            correct: false,
          },
          {
            text: "Nur Jahan",
            correct: false,
          },
          {
            text: "Mumtaz Mahal",
            correct: true,
          },
        ],
      },
      {
        id: 7,
        question: "Who was the first woman Prime Minister of India?",
        answers: [
          {
            text: "Vijaya Lakshmi Pandit",
            correct: false,
          },
          {
            text: "Pratibha Patil",
            correct: false,
          },
          {
            text: "Indira Gandhi",
            correct: true,
          },
          {
            text: "Sarojini Naidu",
            correct: false,
          },
        ],
      },
      {
        id: 8,
        question: "The Dandi March, a significant civil disobedience movement, was led by which Indian leader?",
        answers: [
          {
            text: "Bhagat Singh",
            correct: false,
          },
          {
            text: "Subhash Chandra Bose",
            correct: false,
          },
          {
            text: "Jawaharlal Nehru",
            correct: false,
          },
          {
            text: "Mahatma Gandhi",
            correct: true,
          },
        ],
      },
      {
        id: 9,
        question: "The famous Sanchi Stupa is located in which Indian state?",
        answers: [
          {
            text: "Uttar Pradesh",
            correct: false,
          },
          {
            text: "Bihar",
            correct: false,
          },
          {
            text: "Madhya Pradesh",
            correct: true,
          },
          {
            text: "Rajasthan",
            correct: false,
          },
        ],
      },
      {
        id: 10,
        question: "Who was the first Indian to win the Nobel Prize?",
        answers: [
          {
            text: "Rabindranath Tagore",
            correct: true,
          },
          {
            text: "C.V. Raman",
            correct: false,
          },
          {
            text: "Mother Teresa",
            correct: false,
          },
          {
            text: "Amartya Sen",
            correct: false,
          },
        ],
      },
      {
        id: 11,
        question: "The Harappan civilization is also known as the _______ civilization.",
        answers: [
          {
            text: "Mesopotamian",
            correct: false,
          },
          {
            text: "Egyptian",
            correct: false,
          },
          {
            text: "Indus Valley",
            correct: true,
          },
          {
            text: "Vedic",
            correct: false,
          },
        ],
      },
      {
        id: 12,
        question: "The Indian National Congress, a pivotal organization in India's independence movement, was founded in which year?",
        answers: [
          {
            text: "1857",
            correct: false,
          },
          {
            text: "1885",
            correct: true,
          },
          {
            text: "1905",
            correct: false,
          },
          {
            text: "1942",
            correct: false,
          },
        ],
      },
      {
        id: 13,
        question: "The 'Quit India Movement' was launched in which year?",
        answers: [
          {
            text: "1919",
            correct: false,
          },
          {
            text: "1930",
            correct: false,
          },
          {
            text: "1942",
            correct: true,
          },
          {
            text: "1947",
            correct: false,
          },
        ],
      },
      {
        id: 14,
        question: "The Golden Age of ancient Indian culture and arts flourished during the reign of which dynasty?",
        answers: [
          {
            text: "Gupta",
            correct: true,
          },
          {
            text: "Maurya",
            correct: false,
          },
          {
            text: "Chola",
            correct: false,
          },
          {
            text: "Pallava",
            correct: false,
          },
        ],
      },
      {
        id: 15,
        question: "Who was the first Indian astronaut to travel to space?",
        answers: [
          {
            text: "Rakesh Sharma",
            correct: true,
          },
          {
            text: "Kalpana Chawla",
            correct: false,
          },
          {
            text: "Sunita Williams",
            correct: false,
          },
          {
            text: "Abdul Kalam",
            correct: false,
          },
        ],
      },
  ];