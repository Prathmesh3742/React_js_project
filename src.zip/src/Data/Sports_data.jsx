export const data1 = [
    {
      id: 1,
      question: "Who is the only player to have scored in a Champions League final, an FA Cup final, a UEFA Cup final and a League Cup final?",
      answers: [
        {
          text: "Cristiano Ronaldo",
          correct: false,
        },
        {
          text: "Ryan Giggs",
          correct: true,
        },
        {
          text: "Thierry Henry",
          correct: false,
        },
        {
          text: "Steven Gerrard",
          correct: false,
        },
      ],
    },
    {
        id: 2,
        question: "Who is the only player to have won the Champions League with three different clubs?",
        answers: [
          {
            text: "Zlatan Ibrahimovic",
            correct: false,
          },
          {
            text: "Lionel Messi",
            correct: false,
          },
          {
            text: "Cristiano Ronaldo",
            correct: false,
          },
          {
            text: "Clarence Seedorf",
            correct: true,
          },
        ],
      },
      {
        id: 3,
        question: "Who is the only player to have won the Ballon d'Or four times in a row?",
        answers: [
          {
            text: "Michel Platini",
            correct: true,
          },
          {
            text: "Johan Cruyff",
            correct: false,
          },
          {
            text: "Lionel Messi",
            correct: false,
          },
          {
            text: "Cristiano Ronaldo",
            correct: false,
          },
        ],
      },
      {
        id: 4,
        question: "Who is the only player to have won the World Cup as both a player and a coach?",
        answers: [
          {
            text: "Diego Maradona",
            correct: false,
          },
          {
            text: "Franz Beckenbauer",
            correct: true,
          },
          {
            text: "Zinedine Zidane",
            correct: false,
          },
          {
            text: "Johan Cruyff",
            correct: false,
          },
        ],
      },
      {
        id: 5,
        question: "Which country has won the most World Cup titles?",
        answers: [
          {
            text: "Germany",
            correct: false,
          },
          {
            text: "Argentina",
            correct: false,
          },
          {
            text: "Italy",
            correct: false,
          },
          {
            text: "Brazil",
            correct: true,
          },
        ],
      },
      {
        id: 6,
        question: "Which country has won the most Olympic gold medals in athletics?",
        answers: [
          {
            text: "Soviet Union (USSR)",
            correct: false,
          },
          {
            text: "China",
            correct: false,
          },
          {
            text: "United States of America (USA)",
            correct: true,
          },
          {
            text: "Jamaica",
            correct: false,
          },
        ],
      },
      {
        id: 7,
        question: "Which country has won the most Olympic gold medals in swimming?",
        answers: [
          {
            text: "Australia",
            correct: false,
          },
          {
            text: "United States of America (USA)",
            correct: true,
          },
          {
            text: "China",
            correct: false,
          },
          {
            text: "Russia (USSR)",
            correct: false,
          },
        ],
      },
      {
        id: 8,
        question: "Who is the only athlete to win Olympic gold medals in both the 100m and 400m events?",
        answers: [
          {
            text: "Usain Bolt",
            correct: false,
          },
          {
            text: "Carl Lewis",
            correct: false,
          },
          {
            text: "Jesse Owens",
            correct: false,
          },
          {
            text: "Michael Johnson",
            correct: true,
          },
        ],
      },
      {
        id: 9,
        question: "Which country has won the most Olympic gold medals in basketball?",
        answers: [
          {
            text: "Soviet Union (USSR)",
            correct: false,
          },
          {
            text: "United States of America (USA)",
            correct: true,
          },
          {
            text: "Yugoslavia (YUG)",
            correct: false,
          },
          {
            text: "Argentina (ARG)",
            correct: false,
          },
        ],
      },
      {
        id: 10,
        question: "Who is the only athlete to win Olympic gold medals in both diving and gymnastics?",
        answers: [
          {
            text: "Fu Mingxia",
            correct: true,
          },
          {
            text: "Olga Korbut",
            correct: false,
          },
          {
            text: "Nadia Comaneci ",
            correct: false,
          },
          {
            text: "Greg Louganis",
            correct: false,
          },
        ],
      },
      {
        id: 11,
        question: "Who holds the record for the most home runs in Major League Baseball history?",
        answers: [
          {
            text: "Babe Ruth",
            correct: false,
          },
          {
            text: "Barry Bonds",
            correct: true,
          },
          {
            text: "Hank Aaron",
            correct: false,
          },
          {
            text: "Ted Williams",
            correct: false,
          },
        ],
      },
      {
        id: 12,
        question: "Which tennis player has won the most Grand Slam titles in the men's singles category?",
        answers: [
          {
            text: "Roger Federer",
            correct: false,
          },
          {
            text: "Rafael Nadal",
            correct: false,
          },
          {
            text: "Rod Laver",
            correct: true,
          },
          {
            text: "Novak Djokovic",
            correct: false,
          },
        ],
      },
      {
        id: 13,
        question: "Which country hosted the 2016 Summer Olympics?",
        answers: [
          {
            text: "China",
            correct: false,
          },
          {
            text: "Russia",
            correct: false,
          },
          {
            text: "Brazil",
            correct: true,
          },
          {
            text: "Qatar",
            correct: false,
          },
        ],
      },
      {
        id: 14,
        question: "In golf, what is the name of the annual tournament that is played at Augusta National Golf Club?",
        answers: [
          {
            text: "The British Open",
            correct: false,
          },
          {
            text: "The Masters",
            correct: true,
          },
          {
            text: "The Russian open",
            correct: false,
          },
          {
            text: "The U.S. Open",
            correct: false,
          },
        ],
      },
      {
        id: 15,
        question: "Which NBA player is known as 'The Black Mamba'?",
        answers: [
          {
            text: "LeBron James",
            correct: false,
          },
          {
            text: "Kevin Durant",
            correct: false,
          },
          {
            text: "Dirk Nowitzki",
            correct: false,
          },
          {
            text: "Kobe Bryant",
            correct: true,
          },
        ],
      },
]