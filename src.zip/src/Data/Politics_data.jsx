export const data2 = [
    {
      id: 1,
      question: "What is the capital of France?",
      answers: [
        {
          text: "Berlin",
          correct: false,
        },
        {
          text: "Paris",
          correct: true,
        },
        {
          text: "Rome",
          correct: false,
        },
        {
          text: "Madrid",
          correct: false,
        },
      ],
    },
    {
        id: 2,
        question: "Who is the current President of the United States?",
        answers: [
          {
            text: "Barack Obama",
            correct: false,
          },
          {
            text: "Donald Trump",
            correct: false,
          },
          {
            text: "Joe Biden",
            correct: true,
          },
          {
            text: "George W. Bush",
            correct: false,
          },
        ],
      },
      {
        id: 3,
        question: "What is the system of government in which a monarch holds supreme authority?",
        answers: [
          {
            text: "Monarchy",
            correct: true,
          },
          {
            text: "Oligarchy",
            correct: false,
          },
          {
            text: "Anarchy",
            correct: false,
          },
          {
            text: "Democracy",
            correct: false,
          },
        ],
      },
      {
        id: 4,
        question: "Which document established the foundation of the United States government?",
        answers: [
          {
            text: "The Declaration of Independence",
            correct: false,
          },
          {
            text: "The Constitution",
            correct: true,
          },
          {
            text: "The Bill of Rights",
            correct: false,
          },
          {
            text: "he Magna Carta",
            correct: false,
          },
        ],
      },
      {
        id: 5,
        question: "Who wrote the book 'The Communist Manifesto'?",
        answers: [
          {
            text: "Karl Marx",
            correct: true,
          },
          {
            text: "Adam Smith",
            correct: false,
          },
          {
            text: "Vladimir Lenin",
            correct: false,
          },
          {
            text: "Friedrich Hayek",
            correct: false,
          },
        ],
      },
      {
        id: 6,
        question: "What is the legislative branch of the European Union called?",
        answers: [
          {
            text: "European Commission",
            correct: false,
          },
          {
            text: "European Court of Justice",
            correct: false,
          },
          {
            text: "European Parliament",
            correct: true,
          },
          {
            text: "European Council",
            correct: false,
          },
        ],
      },
      {
        id: 7,
        question: "Which country is known as the 'Land of the Rising Sun'?",
        answers: [
          {
            text: "China",
            correct: false,
          },
          {
            text: "South Korea",
            correct: false,
          },
          {
            text: "Thailand",
            correct: false,
          },
          {
            text: "Japan",
            correct: true,
          },
        ],
      },
      {
        id: 8,
        question: "What economic theory promotes minimal government intervention in the economy?",
        answers: [
          {
            text: "Communism",
            correct: false,
          },
          {
            text: "Laissez-faire",
            correct: true,
          },
          {
            text: "Socialism",
            correct: false,
          },
          {
            text: "Capitalism",
            correct: false,
          },
        ],
      },
      {
        id: 9,
        question: "Who is often referred to as the 'Iron Lady' due to her strong leadership style?",
        answers: [
          {
            text: "Margaret Thatcher",
            correct: true,
          },
          {
            text: "Angela Merkel",
            correct: false,
          },
          {
            text: "Theresa May",
            correct: false,
          },
          {
            text: "Queen Elizabeth II",
            correct: false,
          },
        ],
      },
      {
        id: 10,
        question: "What is the main legislative body of the United Nations?",
        answers: [
          {
            text: "Security Council",
            correct: false,
          },
          {
            text: "Secretariat",
            correct: false,
          },
          {
            text: "International Court of Justice",
            correct: false,
          },
          {
            text: "General Assembly",
            correct: true,
          },
        ],
      },
      {
        id: 11,
        question: "What is the official currency of China?",
        answers: [
          {
            text: "Yen",
            correct: false,
          },
          {
            text: "Renminbi",
            correct: true,
          },
          {
            text: "Won",
            correct: false,
          },
          {
            text: "Baht",
            correct: false,
          },
        ],
      },
      {
        id: 12,
        question: "Which country was not a part of the Axis Powers during World War II?",
        answers: [
          {
            text: "Japan",
            correct: false,
          },
          {
            text: "Italy",
            correct: false,
          },
          {
            text: "France",
            correct: true,
          },
          {
            text: "Germany",
            correct: false,
          },
        ],
      },
      {
        id: 13,
        question: "In the United Kingdom, what is the title of the upper house of Parliament?",
        answers: [
          {
            text: "House of Representatives",
            correct: false,
          },
          {
            text: "House of Lords",
            correct: true,
          },
          {
            text: "Senate",
            correct: false,
          },
          {
            text: "House of Commons",
            correct: false,
          },
        ],
      },
      {
        id: 14,
        question: "Who is considered the father of modern political philosophy and wrote 'Leviathan'?",
        answers: [
          {
            text: "Thomas Hobbes",
            correct: true,
          },
          {
            text: "Jean-Jacques Rousseau",
            correct: false,
          },
          {
            text: "Montesquieu",
            correct: false,
          },
          {
            text: "John Locke",
            correct: false,
          },
        ],
      },
      {
        id: 15,
        question: "Which amendment to the US Constitution guarantees freedom of speech?",
        answers: [
          {
            text: "Fourth Amendment",
            correct: false,
          },
          {
            text: "First Amendmen",
            correct: true,
          },
          {
            text: "Fifth Amendment",
            correct: false,
          },
          {
            text: "Tenth Amendment",
            correct: false,
          },
        ],
      },
  ];
