export const data4 = [
    {
      id: 1,
      question: "What is the capital of France?",
      answers: [
        {
          text: "Berlin",
          correct: false,
        },
        {
          text: "Paris",
          correct: true,
        },
        {
          text: "Madrid",
          correct: false,
        },
        {
          text: "Rome",
          correct: false,
        },
      ],
    },
    {
      id: 2,
      question: "which river is the longest in the world?",
      answers: [
        {
          text: "Nile",
          correct: true,
        },
        {
          text: "Amazon",
          correct: false,
        },
        {
          text: "Mississippi",
          correct: false,
        },
        {
          text: "Yangtze",
          correct: false,
        },
      ],
    },
    {
      id: 3,
      question: "Which country is known as the land of rising sun?",
      answers: [
        {
          text: "China",
          correct: false,
        },
        {
          text: "South Korea",
          correct: false,
        },
        {
          text: "Thailand",
          correct: false,
        },
        {
          text: "Japan",
          correct: true,
        },
      ],
    },
    {
        id: 4,
        question: "What is the largest ocean in the world?",
        answers: [
          {
            text: "Pacific Ocean",
            correct: true,
          },
          {
            text: "Indian Ocean",
            correct: false,
          },
          {
            text: "Atlantic Ocean",
            correct: false,
          },
          {
            text: "Arctic Ocean",
            correct: false,
          },
        ],
      },
      {
        id: 5,
        question: "What is the largest desert in the world?",
        answers: [
          {
            text: "Atacama Desert",
            correct: false,
          },
          {
            text: "Gobi Desert",
            correct: false,
          },
          {
            text: "Sahara Desert",
            correct: true,
          },
          {
            text: "Kalahari Desert",
            correct: false,
          },
        ],
      },
      {
        id: 6,
        question: "What is the smallest country in the world by land area?",
        answers: [
          {
            text: "Monaco",
            correct: false,
          },
          {
            text: "Vatican City",
            correct: true,
          },
          {
            text: "Liechtenstein",
            correct: false,
          },
          {
            text: "San Marino",
            correct: false,
          },
        ],
      },
      {
        id: 7,
        question: "Which city is the capital of Japan?",
        answers: [
          {
            text: "Tokyo",
            correct: true,
          },
          {
            text: "Beijing",
            correct: false,
          },
          {
            text: "Seoul",
            correct: false,
          },
          {
            text: "Bangkok",
            correct: false,
          },
        ],
      },
      {
        id: 8,
        question: "Which continent is the largest by land area?",
        answers: [
          {
            text: "Europe",
            correct: false,
          },
          {
            text: "North America",
            correct: false,
          },
          {
            text: "Asia",
            correct: true,
          },
          {
            text: "Africa",
            correct: false,
          },
        ],
      },
      {
        id: 9,
        question: "What is the capital of Russia?",
        answers: [
          {
            text: "Warsaw",
            correct: false,
          },
          {
            text: "Kiev",
            correct: false,
          },
          {
            text: "St. Petersburg",
            correct: false,
          },
          {
            text: "Moscow",
            correct: true,
          },
        ],
      },
      {
        id: 10,
        question: "What is the highest mountain in Africa?",
        answers: [
          {
            text: "Mount Kenya",
            correct: false,
          },
          {
            text: "Mount Everest",
            correct: false,
          },
          {
            text: "Mount McKinley",
            correct: false,
          },
          {
            text: "Mount Kilimanjaro",
            correct: true,
          },
        ],
      },
      {
        id: 11,
        question: "Which country is known for having the most islands in the world?",
        answers: [
          {
            text: "Australia",
            correct: false,
          },
          {
            text: "Indonesia",
            correct: true,
          },
          {
            text: "Japan",
            correct: false,
          },
          {
            text: "Canada",
            correct: false,
          },
        ],
      },
      {
        id: 12,
        question: "Which continent is known as the 'Dark Continent'?",
        answers: [
          {
            text: "Antarctica",
            correct: false,
          },
          {
            text: "Asia",
            correct: false,
          },
          {
            text: "Africa",
            correct: true,
          },
          {
            text: "South America",
            correct: false,
          },
        ],
      },
      {
        id: 13,
        question: "Which mountain range spans across seven countries in South America?",
        answers: [
          {
            text: "Himalayas",
            correct: false,
          },
          {
            text: "Rocky Mountains",
            correct: false,
          },
          {
            text: "Andes",
            correct: true,
          },
          {
            text: "Alps",
            correct: false,
          },
        ],
      },
      {
        id: 14,
        question: "Which country is famous for its tulips and windmills?",
        answers: [
          {
            text: "Netherlands",
            correct: true,
          },
          {
            text: "Italy",
            correct: false,
          },
          {
            text: "Sweden",
            correct: false,
          },
          {
            text: "Greece",
            correct: false,
          },
        ],
      },
      {
        id: 15,
        question: "In which country is the Great Barrier Reef located?",
        answers: [
          {
            text: "Canada",
            correct: false,
          },
          {
            text: "Brazil",
            correct: false,
          },
          {
            text: "Australia",
            correct: true,
          },
          {
            text: "India",
            correct: false,
          },
        ],
      },
  ];