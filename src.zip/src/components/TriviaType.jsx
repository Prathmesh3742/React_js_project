import { data1 } from "../Data/Sports_data";
import { data2 } from "../Data/Politics_data";
import { data3 } from "../Data/History_Data";
import { data4 } from "../Data/Geo_data";

export default function TriviaType({
    setTriviaType,
    data,
    setData,
}){
    return (
        <div className="triviatype">
          <div className="choosetype">Select the type of quiz</div>
          <div className="options">
            <div className="option" onClick={()=>{
              console.log("hi")
                setData(data1)
                setTriviaType("Sports")
                return data
            }}>
                Sports
            </div>
            <div className="option" onClick={()=>{
                setData(data2)
                setTriviaType("Politics")
            }}>
                Politics
            </div>
            <div className="option" onClick={()=>{
                setData(data3)
                setTriviaType("History")
            }}>
                History
            </div>
            <div className="option" onClick={()=>{
                setData(data4)
                setTriviaType("Geography")
            }}>
                Geography
            </div>
            </div>
        </div>
      );
}